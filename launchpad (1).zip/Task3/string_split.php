<?php

namespace second;
class first{
function split(){

    $str = "hello world";
    print_r(str_split($str));

}
}
