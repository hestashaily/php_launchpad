<?php

namespace first;
class first{
function reverse()
{
    $str = "hello world";

    echo strrev($str);
}
}
