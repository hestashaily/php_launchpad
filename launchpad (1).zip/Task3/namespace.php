<?php

use function first\reverse;

require_once('string_reverse.php');
require_once('string_split.php');


$obj=new first\first();
$obj->reverse();

$obj=new second\first();
$obj->split();