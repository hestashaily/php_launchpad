<?php
class Calculator {
    private $_val1 ;
    private $_val2;

    public function __construct($val1, $val2){
        $this->_val1 = $val1;
        $this->_val2 = $val2;
    }

    public function add(){
        return $this->_val1 + $this->_val2;
    }

    public function subtract(){
        return $this->_val1 - $this->_val2;
    }
    
    public function multiply (){
        return $this->_val1 * $this->_val2;
    }

    public function divide () {
        return $this->_val1 / $this->_val2;
    }
}

$calc = new Calculator(8,4);
echo "<p>8+ 4 = ".$calc->add(). "</p>";

$calc = new Calculator (150,8);
echo "<p>150 - 8 = ".$calc->subtract(). "</p>";

$calc = new Calculator (200,4);
echo "<p> 200* 4= ".$calc->multiply(). "</p>";

$calc = new Calculator (8000,5);
echo "<p> 8000/ 5= ".$calc ->divide(). "</p>";    