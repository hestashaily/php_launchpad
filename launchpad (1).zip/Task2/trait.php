<?php

trait div{
    function divide(){
        $a=4;
        $b=2;
        echo $a/$b;
    }
}


class temp {
    use div;
}

$obj=new temp();
$obj->divide();