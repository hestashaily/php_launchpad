<?php
class Calculator
{
    private $_val1, $_val2;

    public function __construct($val1, $val2)
    {
        $this->_val1 = $val1;
        $this->_val2 = $val2;
    }

    public function add()
    {
        return $this->_val1 + $this->_val2;
    }

    public function subtract()
    {
        return $this->_val1 - $this->_val2;
    }  
    
}

$calc = new Calculator(8, 4);
echo "<p>8 + 4 = " . $calc->add() . "</p>";

$calc = new Calculator(90, 9);
echo "<p>90- 9= " . $calc->subtract() . "</p>";

?>
