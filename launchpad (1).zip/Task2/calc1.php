<?php

trait div{
    function divide(){
        $a=4;
        $b=2;
        echo $a/$b;
    }
}
trait add{
    function addition(){
        $a=4;
        $b=4;
        echo $a+$b;
    }
}
trait mul{
    function multiply(){
        $a=100;
        $b=5;
        echo $a*$b;
    }
}


class demo{
    use div;
    use add;
    use mul;
}

$obj=new demo();
$obj->divide();
$obj->addition();
$obj->multiply();