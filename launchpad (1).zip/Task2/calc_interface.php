<?php
interface parent1{
    public function add($a,$b);
    public function sub($c,$d);
    public function mul($e,$f);
    public function div($g,$h);
}

class childClass implements parent1{
    public function add($a,$b){
        echo $a + $b;
    }
    public function sub($c,$d){
        echo $c - $d;
    }
    public function mul($e,$f){
        echo $e *$f;
    }
    public function div($g,$h){
        echo $g/$h;
    }
}
$test= new childClass();
$test-> add(6,7);
$test->sub(89,8);
$test->mul(67,9);
$test->div(5000,5);