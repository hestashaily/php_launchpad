<?php
require_once("impo.php");
$data = array(
    "Name"=>"shaily",
    "Email"=>"1214@gmail.com",
    "password"=>"password12" 
);
$obj=new Orm();
echo $result = $obj->insert("user",$data);