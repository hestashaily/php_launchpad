<?php
require_once("impo.php");
$obj=new Orm();
$col_Name=array("Name","Email");
$data=$obj->select("user",$col_Name);
print_r($data);