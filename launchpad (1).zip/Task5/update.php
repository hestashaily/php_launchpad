<?php
require_once("impo.php");
$obj= new Orm();
$data= "Name = 'harry',Email = 'mail.com',password = 'password1234'";
$where = "Name = 'shaily'";
$result = $obj ->update('user',$data,$where);