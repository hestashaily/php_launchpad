<?php
require_once("impo.php");
$obj=new Orm();
$where ="Name  = 'harry'";
$result = $obj ->delete('user',$where);
