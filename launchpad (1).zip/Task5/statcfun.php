<?php
//creating a connection with database using static or singleton method!
Interface a{
    public static function welcomeee();
}
class Greeting implements a{
        public static function welcomeee(){
        static $conn;
      
        if($conn==null){
            $conn=mysqli_connect('localhost','hestabit','hestabit','create_database_data') or die("Sorry someting is wrong");
            return $conn;
        }else{
            return $conn;
        }
    }
}
$conn=Greeting::welcomeee();




