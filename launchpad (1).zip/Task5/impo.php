<?php
require_once('statcfun.php');
class Orm
{
    //function for selection of data.
    public function select($table_name, $col_data)
    {
        $conn = $GLOBALS['conn'];
        $col_data=implode(',',$col_data);
        $query = "Select $col_data from $table_name ";
        $query_result = mysqli_query($conn, $query);
        $select_data = mysqli_fetch_array($query_result);
        return $select_data;

    }
    //function for insert
    public function insert($table_name,$col_data){
        $conn = $GLOBALS['conn'];
        $col_name=array_keys($col_data);
        $col_name_as_string=implode(',',$col_name);
        $col_value=array_values($col_data);
        $col_value_as_string=implode("','",$col_value);
        echo $query = "INSERT INTO $table_name ($col_name_as_string)VALUES ('$col_value_as_string')";
        $query_result = mysqli_query($conn,$query) or die('error');
        return $query_result;
    }
    //function for updates
    public function update($table_name,$col_data,$where){
        $conn = $GLOBALS['conn'];
        
         $query ="UPDATE $table_name SET $col_data where $where";
         $query_result = mysqli_query($conn,$query) or die('Unable to update');
         return $query_result;

        
    }
    //function for deletion
    public function delete($table_name,$where){
        $conn = $GLOBALS['conn'];
        $query = "DELETE FROM $table_name WHERE $where";
        $query_result = mysqli_query($conn,$query) or die("not able to delete!");
        return $query_result;
    }
}