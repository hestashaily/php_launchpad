<?php
// get query parameter
// $param = isset($_GET['test']) ? $_GET['test'] : 'null'

// get length of string
$length = strlen($param);
// check if the length is less than 2, then convert this to uppercase and print the string
if ($length < 2) {
    first($param);
    $upperCaseString = strtoupper($param);
    // echo $upperCaseString;
} elseif ($length >= 2 && false === strpos(trim($param), ' ')) {
    Second($parma);
} elseif ($length > 2 && strpos(trim($param), ' ') > 0) {
    three($param);
} else {
    fourth();
}

function first($param)
{
    $upperCaseString = strtoupper($param);
    echo $upperCaseString;
}
function Second($param)
{
    $lowerCaseString = strtolower($param);
    echo $lowerCaseString;
}

function fourth()
{
    echo "Could not understand the string";
}
function three($param)
{
    $sentenceCaseString = ucfirst(strtolower($param));
    echo $sentenceCaseString;
}
?>
<!-- /var/www/html/launchpad/Task1/function_implementation.php -->